package Pages;

import Base.BaseClass;
import Base.Operations;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class Payment extends BaseClass {

    private static WebDriverWait wait = new WebDriverWait(driver, Duration.ofMillis(60000));
    private static class Locator {
        private static By cardNameInput = By.name("name_on_card");
        private static By cardNumberInput = By.name("card_number");
        private static By cardCVCInput = By.name("cvc");
        private static By cardExpireyMonthInput = By.name("expiry_month");
        private static By cardExpireyYearInput = By.name("expiry_year");
        private static By paymentConfirmBtn = By.id("submit");
        private static By paymentSuccessMsg = By.id("success_message");
        private static String successMsgText = "Your order has been placed successfully!";

    }

    public static void enterPaymentDetails() {
        wait.until(ExpectedConditions.presenceOfElementLocated(Locator.paymentConfirmBtn));

        Operations.enterText(BaseClass.properties.getProperty("cardName"), Locator.cardNameInput, driver);
        Operations.enterText(BaseClass.properties.getProperty("cardNumber"), Locator.cardNumberInput, driver);
        Operations.enterText(BaseClass.properties.getProperty("cvc"), Locator.cardCVCInput, driver);
        Operations.enterText(BaseClass.properties.getProperty("cardExpireyMonth"), Locator.cardExpireyMonthInput, driver);
        Operations.enterText(BaseClass.properties.getProperty("cardExpireyYear"), Locator.cardExpireyYearInput, driver);


    }

    public static void clickPay() {

        Operations.click(Locator.paymentConfirmBtn, driver);
    }

    public static void verifyPaymentSuccessMsg() {
            String actualSuccessMsgText = Operations.getText(Locator.paymentSuccessMsg, driver);
            boolean matches = Operations.matchText(actualSuccessMsgText, Locator.successMsgText);
        }



}


