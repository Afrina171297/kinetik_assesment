package Pages;

import Base.BaseClass;
import Base.Operations;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class Cart extends BaseClass {
    private static WebDriverWait wait = new WebDriverWait(driver, Duration.ofMillis(60000));
    private static class Locator {
        private static By cartElement = By.xpath("//li[text()=\"Shopping Cart\"]");
        private static By proceedToChkOutBtn = By.xpath("//a[text()=\"Proceed To Checkout\"]");
        private static By regBtn = By.xpath("//u[text()=\"Register / Login\"]");
    }
    public static boolean isItCartsScreen() {

        Boolean cartsScreen = false;
        if (Operations.isPresent(Locator.cartElement, driver)) {
            cartsScreen = true;
        }

        return cartsScreen;
    }


    public static void clickProceedToCheckout() {
        wait.until(ExpectedConditions.presenceOfElementLocated(Locator.proceedToChkOutBtn));
        Operations.click(Locator.proceedToChkOutBtn, driver);
    }

    public static void clickRegister() {
        if (Operations.isPresent(Locator.regBtn, driver)) {

            Operations.click(Locator.regBtn, driver);
        }

    }
}
