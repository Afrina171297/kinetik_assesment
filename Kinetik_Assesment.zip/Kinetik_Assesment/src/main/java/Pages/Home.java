package Pages;

import Base.BaseClass;
import Base.Operations;
import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;


public class Home extends BaseClass {
    private static final Color Orange = Color.fromString("rgb(255, 165, 0)");
    private static WebDriverWait wait = new WebDriverWait(driver, Duration.ofMillis(60000));

    private static class Locator {
        private static WebElement homeBtn = driver.findElement(By.xpath("//a[text()=\" Home\"]"));
        private static By brands = By.xpath("//h2[text()=\"Brands\"]");

        private static By product1 = By.xpath("//a[@data-product-id=\"1\"][text()=\"Add to cart\"]");
        private static By product2 = By.xpath("//a[@data-product-id=\"2\"][text()=\"Add to cart\"]");

        private static WebElement productImage1 = driver.findElement(By.xpath("//p[text()=\"Blue Top\"]"));
        private static WebElement productImage2 = driver.findElement(By.xpath("//p[text()=\"Men Tshirt\"]"));
        private static By continueBtn = By.xpath("//button[text()=\"Continue Shopping\"]");

        private static By scrollToCart = By.cssSelector("#header > div > div > div > div.col-sm-4 > div > a > img");
        private static By cartBtn = By.xpath("//a[text()=\" Cart\"]");
        private static By loginUserName = By.xpath("//li/a/b");


    }

    static Color homeButtonColour = Color.fromString(Locator.homeBtn.getCssValue("color"));


    public static boolean isItHomeScreen() {

        Boolean colorMatch = false;
        if (homeButtonColour.equals(Orange)) {
            colorMatch = true;
        }
        return colorMatch;
    }

    public static void scrollToProducts() {
        Operations.scrollIntoElement(Locator.brands, driver);


    }

    public static void addProductToCart() throws InterruptedException {
        Actions action = new Actions(driver);

        if (Operations.isPresent(Locator.product1, driver)) {

            action.moveToElement(Locator.productImage1);

            Operations.click(Locator.product1, driver);

        }
       wait.until(ExpectedConditions.presenceOfElementLocated(Locator.continueBtn));


        if (Operations.isPresent(Locator.continueBtn, driver)) {

            Operations.click(Locator.continueBtn, driver);

        }
       wait.until(ExpectedConditions.presenceOfElementLocated(Locator.product2));



        if (Operations.isPresent(Locator.product2, driver)) {
            action.moveToElement(Locator.productImage2);
            Operations.click(Locator.product2, driver);

        }
        wait.until(ExpectedConditions.presenceOfElementLocated(Locator.continueBtn));


        if (Operations.isPresent(Locator.continueBtn, driver)) {

            Operations.click(Locator.continueBtn, driver);
        }
       wait.until(ExpectedConditions.presenceOfElementLocated(Locator.product2));
       

    }

    public static void clickCarts() {
        wait.until(ExpectedConditions.presenceOfElementLocated(Locator.cartBtn));
        if (Operations.isPresent(Locator.cartBtn, driver)) {
            Operations.click(Locator.cartBtn, driver);
        }
    }

    public static boolean verifyUserName() {

        Boolean verified = false;
        String userName = Register.name;
        wait.until(ExpectedConditions.presenceOfElementLocated(Locator.loginUserName));
        String actualUserName = Operations.getText(Locator.loginUserName, driver);

        if (Operations.matchText(actualUserName, userName)) {
            verified = true;
        }
        System.out.println(verified);

        return verified;
    }


}






